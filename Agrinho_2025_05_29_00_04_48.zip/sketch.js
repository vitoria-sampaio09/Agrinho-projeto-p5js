let fazendeiroX;
let fazendeiroY;
let tamanhoCelula = 50; // Tamanho de cada célula da grade (milho/chão)
let colunas;
let linhas;
let gradeMilho = []; // Matriz 2D para armazenar o estado de cada célula de milho
let milhoColhido = 0; // Contador de milho colhido
// Estados do jogo: 'colheita', 'transicao', 'cidade', 'empresa', 'ganhou'
let estadoJogo = 'colheita';

// Variáveis para a transição do caminhão
let caminhaoX;
let caminhaoY;
let tempoInicioTransicao; // Marca o tempo em que a transição começou
let duracaoTransicao = 10000; // 10 segundos em milissegundos (caminhão na estrada)

// Variáveis para a cena da cidade e empresa
let tempoInicioCidade; // Para controlar o tempo que o caminhão leva para atravessar a cidade
let duracaoViagemCidade = 5000; // 5 segundos para o caminhão atravessar a cidade
let tempoInicioEmpresa; // Para controlar o tempo que o caminhão leva para entrar na empresa
let duracaoEntradaCaminhao = 3000; // 3 segundos para o caminhão entrar
let posPortaoEmpresa; // Posição X do portão da empresa

// Array para armazenar os prédios da cidade (agora são objetos com x e altura)
let alturasPrediosCidade = [];

function setup() {
  createCanvas(800, 600);
  reiniciarJogo(); // Chama a função para configurar o estado inicial do jogo
}

function reiniciarJogo() {
  colunas = floor(width / tamanhoCelula);
  linhas = floor(height / tamanhoCelula);

  fazendeiroX = floor(colunas / 2) * tamanhoCelula;
  fazendeiroY = floor(linhas / 2) * tamanhoCelula;

  for (let i = 0; i < colunas; i++) {
    gradeMilho[i] = [];
    for (let j = 0; j < linhas; j++) {
      gradeMilho[i][j] = 'plantado'; // Estado inicial: milho plantado
    }
  }

  milhoColhido = 0;
  estadoJogo = 'colheita';

  textSize(tamanhoCelula * 0.8);
  textAlign(CENTER, CENTER);

  // O caminhão sempre começa fora da tela à esquerda para a primeira transição
  caminhaoX = -100;
  caminhaoY = height - 100; // Posição vertical do caminhão na rua

  // Preenche os prédios com suas posições X e alturas
  alturasPrediosCidade = [];
  let espacamentoPredio = 80;
  // Criamos mais prédios do que o necessário para preencher a tela, garantindo um loop suave
  for (let i = 0; i < 15; i++) { // Por exemplo, 15 prédios devem ser suficientes para um loop
    let xPos = 50 + i * espacamentoPredio;
    alturasPrediosCidade.push({
      x: xPos,
      altura: random(200, 500)
    });
  }
}

function draw() {
  if (estadoJogo === 'colheita') {
    drawColheitaCena();
  } else if (estadoJogo === 'transicao') {
    drawTransicaoCaminhao();
  } else if (estadoJogo === 'cidade') {
    drawCidadeCena();
  } else if (estadoJogo === 'empresa') {
    drawEmpresaCena();
  } else if (estadoJogo === 'ganhou') {
    drawGanhouCena();
  }
}

function drawColheitaCena() {
  background(135, 206, 235); // Céu azul

  // Desenha a grade de milho
  for (let i = 0; i < colunas; i++) {
    for (let j = 0; j < linhas; j++) {
      if (gradeMilho[i][j] === 'plantado') {
        fill(150, 180, 50); // Cor do milho plantado (amarelo esverdeado)
        noStroke();
        rect(i * tamanhoCelula, j * tamanhoCelula, tamanhoCelula, tamanhoCelula);
        // Desenha "espigas" simples
        fill(200, 200, 50); // Amarelo para a espiga
        ellipse(i * tamanhoCelula + tamanhoCelula * 0.5, j * tamanhoCelula + tamanhoCelula * 0.7, tamanhoCelula * 0.3, tamanhoCelula * 0.4);
      } else {
        fill(100, 70, 40); // Cor do chão após a colheita (marrom seco)
        noStroke();
        rect(i * tamanhoCelula, j * tamanhoCelula, tamanhoCelula, tamanhoCelula);
      }
    }
  }

  // Desenha o fazendeiro (emoji)
  text('👨‍🌾', fazendeiroX + tamanhoCelula / 2, fazendeiroY + tamanhoCelula / 2);

  // Exibe contador de milho colhido e instruções
  fill(0);
  textSize(18);
  textStyle(BOLD);
  textAlign(LEFT, TOP);
  text("Milho colhido: " + milhoColhido + "/10", 10, 10);
  text("Use as setas para mover. Pressione ENTER para colher!", 10, 35);
}

function drawTransicaoCaminhao() {
  background(100); // Fundo cinza escuro para simular o entardecer/noite

  // Desenha a rua (base para o caminhão)
  fill(50);
  rect(0, height - 120, width, 120); // Rua cinza escura
  fill(255, 255, 0); // Linhas da rua
  for (let x = 0; x < width; x += 60) {
    rect(x + (frameCount * 2) % 60, height - 60, 30, 5); // Linhas tracejadas que se movem
  }

  // Desenha o caminhão (simplificado)
  fill(200, 50, 50); // Cor do caminhão (vermelho)
  rect(caminhaoX, caminhaoY - 50, 150, 70); // Corpo do caminhão
  fill(100);
  ellipse(caminhaoX + 30, caminhaoY + 20, 40, 40); // Roda traseira
  ellipse(caminhaoX + 120, caminhaoY + 20, 40, 40); // Roda dianteira
  fill(170, 190, 255);
  rect(caminhaoX + 100, caminhaoY - 40, 40, 20); // Janela

  // Movimenta o caminhão
  let tempoDecorrido = millis() - tempoInicioTransicao;
  if (tempoDecorrido < duracaoTransicao) {
    caminhaoX = map(tempoDecorrido, 0, duracaoTransicao, -150, width + 50); // Caminhão atravessa a tela
  } else {
    estadoJogo = 'cidade'; // Transição termina, vai para a cidade
    tempoInicioCidade = millis(); // Guarda o tempo para a cena da cidade
    // O caminhão deve reaparecer fora da tela à esquerda para a viagem na cidade
    caminhaoX = -150;
  }
}

function drawCidadeCena() {
  background(20, 20, 70); // Céu noturno bem escuro

  // Desenha a rua
  fill(50);
  rect(0, height - 80, width, 80); // Rua cinza escura

  // Desenha prédios grandes e genéricos
  fill(60); // Cor dos prédios
  let espacamentoPredio = 80;
  let velocidadePredios = 2; // Ajuste este valor para mais rápido ou mais lento

  // Loop para desenhar e gerenciar os prédios
  for (let i = 0; i < alturasPrediosCidade.length; i++) {
    let predio = alturasPrediosCidade[i]; // Pega o objeto prédio

    // Se o prédio saiu completamente da tela à esquerda, reposiciona ele na direita
    if (predio.x < -espacamentoPredio) { // Se o prédio sumiu à esquerda
      predio.x = width + espacamentoPredio; // Manda ele para o final da fila de prédios
      predio.altura = random(200, 500); // Opcional: Nova altura para variar os prédios
    }

    // Desenha o prédio
    rect(predio.x, height - 80 - predio.altura, 70, predio.altura);

    // Desenha janelas iluminadas aleatoriamente
    fill(255, 255, 150); // Cor das janelas (amarelo claro)
    for (let j = 0; j < predio.altura - 40; j += 40) {
      if (random(1) > 0.3) { // 70% de chance de ter janela
        rect(predio.x + 10, height - 80 - predio.altura + 10 + j, 20, 20);
        rect(predio.x + 40, height - 80 - predio.altura + 10 + j, 20, 20);
      }
    }
  }

  // Atualiza as posições dos prédios *após* desenhá-los para o próximo frame
  for (let i = 0; i < alturasPrediosCidade.length; i++) {
    alturasPrediosCidade[i].x -= velocidadePredios;
  }

  // Desenha uma lua e algumas estrelas
  fill(255, 255, 200); // Cor da lua
  ellipse(width - 100, 80, 60, 60); // Lua

  // Estrelas
  fill(255, 255, 255);
  for (let i = 0; i < 50; i++) {
    ellipse(random(width), random(height - 200), random(1, 3), random(1, 3));
  }

  // Desenha o caminhão (se movendo na cidade)
  fill(200, 50, 50); // Cor do caminhão (vermelho)
  rect(caminhaoX, caminhaoY - 50, 150, 70); // Corpo do caminhão
  fill(100);
  ellipse(caminhaoX + 30, caminhaoY + 20, 40, 40); // Roda traseira
  ellipse(caminhaoX + 120, caminhaoY + 20, 40, 40); // Roda dianteira
  fill(170, 190, 255);
  rect(caminhaoX + 100, caminhaoY - 40, 40, 20); // Janela

  // Movimenta o caminhão na cidade
  let tempoDecorridoCidade = millis() - tempoInicioCidade;
  if (tempoDecorridoCidade < duracaoViagemCidade) {
    caminhaoX = map(tempoDecorridoCidade, 0, duracaoViagemCidade, -150, width / 2); // Caminhão para no meio da tela da cidade
  } else {
    // Após atravessar a cidade, transiciona para a cena da empresa
    estadoJogo = 'empresa';
    tempoInicioEmpresa = millis(); // Reseta o tempo para a entrada na empresa
    // Posição inicial do caminhão para entrar na empresa
    caminhaoX = 0;
    posPortaoEmpresa = width - 250;
  }
}

function drawEmpresaCena() {
  background(20, 20, 70); // Céu noturno escuro

  // Desenha a rua
  fill(50);
  rect(0, height - 80, width, 80);

  // Desenha a empresa de grãos (maior)
  fill(120, 100, 70); // Cor marrom/ocre para o edifício
  rect(width - 550, height - 80 - 350, 500, 350); // Corpo principal da empresa (maior)
  fill(100, 80, 50); // Cor mais escura para o telhado/parte superior
  rect(width - 560, height - 80 - 370, 520, 20); // Telhado

  // Detalhes da empresa (placa, janela)
  fill(200);
  rect(width - 400, height - 80 - 250, 200, 70); // Placa maior
  fill(0);
  textSize(24); // Texto maior
  textStyle(BOLD);
  textAlign(CENTER, CENTER);
  text("EMPRESA DE GRÃOS", width - 300, height - 80 - 225); // Nome completo

  // Portão da empresa (simulado como uma abertura na parede)
  fill(30, 30, 30); // Cor escura para o portão
  rect(posPortaoEmpresa, height - 80 - 150, 100, 150); // Portão maior

  // Desenha o caminhão (vindo da esquerda para entrar na empresa)
  fill(200, 50, 50); // Cor do caminhão (vermelho)
  rect(caminhaoX, caminhaoY - 50, 150, 70); // Corpo do caminhão
  fill(100);
  ellipse(caminhaoX + 30, caminhaoY + 20, 40, 40); // Roda traseira
  ellipse(caminhaoX + 120, caminhaoY + 20, 40, 40); // Roda dianteira
  fill(170, 190, 255);
  rect(caminhaoX + 100, caminhaoY - 40, 40, 20); // Janela

  // Animação do caminhão entrando na empresa
  let tempoDecorrido = millis() - tempoInicioEmpresa;
  if (tempoDecorrido < duracaoEntradaCaminhao) {
    // Caminhão se move da esquerda até o portão e entra
    caminhaoX = map(tempoDecorrido, 0, duracaoEntradaCaminhao, 0, posPortaoEmpresa + 50); // Ajuste para o caminhão entrar
  } else {
    // Quando o caminhão entra, muda para a cena de "GANHOU"
    estadoJogo = 'ganhou';
  }
}

function drawGanhouCena() {
  background(50, 150, 50); // Fundo verde vibrante de sucesso

  fill(255); // Cor branca para o texto
  textSize(64);
  textStyle(BOLD);
  textAlign(CENTER, CENTER);
  text("VOCÊ GANHOU!", width / 2, height / 2 - 50);

  textSize(24);
  textStyle(NORMAL);
  text("Sua colheita de milho foi entregue com sucesso!", width / 2, height / 2 + 20);
  text("Pressione 'R' para jogar novamente.", width / 2, height / 2 + 80);
}

function keyPressed() {
  // O movimento do fazendeiro e a colheita só funcionam no estado 'colheita'
  if (estadoJogo === 'colheita') {
    if (keyCode === LEFT_ARROW) {
      fazendeiroX -= tamanhoCelula;
    } else if (keyCode === RIGHT_ARROW) {
      fazendeiroX += tamanhoCelula;
    } else if (keyCode === UP_ARROW) {
      fazendeiroY -= tamanhoCelula;
    } else if (keyCode === DOWN_ARROW) {
      fazendeiroY += tamanhoCelula;
    }

    fazendeiroX = constrain(fazendeiroX, 0, width - tamanhoCelula);
    fazendeiroY = constrain(fazendeiroY, 0, height - tamanhoCelula);

    // Ação de "colher" ao pressionar ENTER
    if (keyCode === ENTER) {
      let colAtual = floor(fazendeiroX / tamanhoCelula);
      let linAtual = floor(fazendeiroY / tamanhoCelula);

      if (gradeMilho[colAtual][linAtual] === 'plantado') {
        gradeMilho[colAtual][linAtual] = 'colhido'; // Milho colhido
        milhoColhido++;

        // Inicia a transição quando 10 milhos são colhidos
        if (milhoColhido >= 10) {
          estadoJogo = 'transicao';
          tempoInicioTransicao = millis();
          caminhaoX = -150; // Reseta a posição do caminhão para a transição
        }
      }
    }
  } else if (estadoJogo === 'ganhou') {
    // Reinicia o jogo se 'R' for pressionado na tela de 'GANHOU'
    if (key === 'r' || key === 'R') {
      reiniciarJogo();
    }
  }
}
